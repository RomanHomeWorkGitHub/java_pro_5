package org.example.services;

import org.example.dao.ProductDao;
import org.example.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    ProductDao productDao;

    public List<Product> getAllProducts(String id) throws SQLException {
          return productDao.getAllProducts(Long.valueOf(id));
    }

    public Product getProductByProductId(String id) throws SQLException {
        return productDao.getProductByProductId(Long.valueOf(id));
        }
}
