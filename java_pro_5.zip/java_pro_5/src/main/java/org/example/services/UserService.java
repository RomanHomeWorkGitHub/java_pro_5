package org.example.services;

import lombok.AllArgsConstructor;
import org.example.dao.UserDao;
import org.example.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
@AllArgsConstructor
public class UserService {

    @Autowired
    UserDao userDao;

    public List<User> getUsers() throws SQLException {
        return userDao.getUsers();
    }

    public User getUserById(long id) throws SQLException {
        return userDao.getUserById(id);
    }

    public boolean createUser(User user) throws SQLException {
        return userDao.createUser(user);
    }

    public boolean updateUser(User user) throws SQLException {
        return userDao.updateUser(user);
    }

    public boolean deleteUser(long id) throws SQLException {
        return userDao.deleteUser(id);
    }
}
