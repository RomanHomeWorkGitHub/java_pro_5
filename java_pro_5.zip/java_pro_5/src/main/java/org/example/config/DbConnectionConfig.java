package org.example.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@Configuration
@ComponentScan()
@PropertySource("classpath:application.yml")
public class DbConnectionConfig {

    @Autowired
    Environment env;

    @Bean("dataSource")
    public DataSource getDataSource() {
        HikariConfig config = new HikariConfig();

        config.setJdbcUrl(env.getProperty("url"));
        config.setUsername(env.getProperty("username"));
        config.setPassword(env.getProperty("password"));
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        return new HikariDataSource(config);
    }

    @Bean
    public Connection getConnection(@Qualifier("dataSource") DataSource ds) throws SQLException {
        return ds.getConnection();
    }

    @Bean
    public TomcatServletWebServerFactory webServerFactory() {
        TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
        factory.addConnectorCustomizers((Connector connector) -> {
            connector.setProperty("relaxedPathChars", "\"#<>[\\]^`{|}");
            connector.setProperty("relaxedQueryChars", "\"#<>[\\]^`{|}");
        });
        return factory;
    }
}



