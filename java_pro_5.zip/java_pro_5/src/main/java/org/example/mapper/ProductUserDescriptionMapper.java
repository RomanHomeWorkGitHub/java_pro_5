package org.example.mapper;

import org.example.model.ProductUserDescription;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
public class ProductUserDescriptionMapper {

    public List<ProductUserDescription> mapToProduct(ResultSet resultSet) throws SQLException {
        List<ProductUserDescription> puds = new ArrayList<>();
        while (resultSet.next()) {
            ProductUserDescription pud = new ProductUserDescription(
                    resultSet.getLong("id"),
                    resultSet.getString("account_number"),
                    resultSet.getLong("user_id"));
            puds.add(pud);
        }
        return puds;
    }
}
