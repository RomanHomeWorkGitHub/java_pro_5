package org.example.dao;

import jakarta.annotation.PreDestroy;
import org.example.mapper.ProductMapper;
import org.example.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ProductUserDescriptionDao {

    @Autowired
    ProductMapper productMapper;

    @Autowired
    Connection connection;

    @PreDestroy
    void close() throws SQLException {
        connection.close();
    }

    public List<Product> getAllProductsByUserId(Long id) throws SQLException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
       String sql = "SELECT * FROM product WHERE id IN (SELECT id FROM prdctusrdscrptn WHERE user_id = ?)";
        try (PreparedStatement pst = connection.prepareStatement("SELECT * FROM product WHERE id IN (SELECT id FROM prdctusrdscrptn WHERE user_id = ?)")) {
            pst.setLong(1, id);
            return productMapper.mapToProduct(pst.executeQuery());
       }
    }

    public Product getProductByProductId(Long id) throws SQLException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        try (PreparedStatement pst = connection.prepareStatement("SELECT * FROM PRODUCT WHERE id = ?")) {
            pst.setLong(1, id);
            return productMapper.mapToProduct(pst.executeQuery()).get(0);
        }
    }
}
