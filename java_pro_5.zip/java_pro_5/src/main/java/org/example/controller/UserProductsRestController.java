package org.example.controller;

import org.example.model.Product;
import org.example.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("org/example")
class UserProductsRestController {

    @Autowired
    ProductService productService;


    @GetMapping("/{id}/getAllProducts")
    public ResponseEntity<List<Product>> getAllProducts(@PathVariable String id) throws SQLException {
        return ResponseEntity.ok(productService.getAllProducts(id));
    }

    @GetMapping("/getProduct")
    public ResponseEntity<Product> getProductByProductId(@RequestParam String productId) throws SQLException {
        return ResponseEntity.ok(productService.getProductByProductId(productId));
    }
}
