package org.example.dao;

import org.example.Main;
import org.example.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ProductUserDescriptionDaoTest {

    private ProductDao productDao;

    @BeforeEach
    void setUp() {
        ApplicationContext ac = new AnnotationConfigApplicationContext(Main.class);
        productDao = (ProductDao) ac.getBean("productDao");
    }

    @Test
    void getAllProducts() throws SQLException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        List<Product> products = productDao.getAllProducts(1L);
        assertEquals(2, products.size());
        assertEquals("C12345", products.get(0).getAccount_number());
        assertEquals("C23451", products.get(1).getAccount_number());
        products = productDao.getAllProducts(2L);
        assertEquals(2, products.size());
        assertEquals("C45123", products.get(0).getAccount_number());
        assertEquals("A34512", products.get(1).getAccount_number());
        products = productDao.getAllProducts(3L);
        assertEquals(1, products.size());
        assertEquals("A51234", products.get(0).getAccount_number());
    }

    @Test
    void getProductByProductId() throws SQLException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        Product products = productDao.getProductByProductId(1L);
        assertEquals("C12345", products.getAccount_number());
        products = productDao.getProductByProductId(2L);
        assertEquals("C23451", products.getAccount_number());
        products = productDao.getProductByProductId(3L);
        assertEquals("A34512", products.getAccount_number());
        products = productDao.getProductByProductId(4L);
        assertEquals("C45123", products.getAccount_number());
        products = productDao.getProductByProductId(5L);
        assertEquals("A51234", products.getAccount_number());
        }
}